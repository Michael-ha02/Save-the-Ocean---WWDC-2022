//
//  File.swift
//  MyApp
//
//  Created by Michael Ha on 4/13/22.
//

import Foundation

enum Page {
    case intro
    case content
    case page1
    case page2
    case page3
    case page4
}
