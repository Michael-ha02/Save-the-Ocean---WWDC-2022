//
//  ViewRouter.swift
//  MyApp
//
//  Created by Michael Ha on 4/13/22.
//

import SwiftUI

class ViewRouter: ObservableObject {
    @Published var currentPage: Page = .intro
}
