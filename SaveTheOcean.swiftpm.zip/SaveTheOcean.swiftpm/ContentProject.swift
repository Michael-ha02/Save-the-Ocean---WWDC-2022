//
//  File.swift
//  MyApp
//
//  Created by Michael Ha on 4/15/22.
//


import SwiftUI
import AVFoundation

struct ContentProject: View{
    @State var audioPlayer: AVAudioPlayer!
    @State var willMoveToNextScreen = false
    @StateObject var viewRouter: ViewRouter
    
    var body: some View{
        
        ZStack(alignment: .center){
            ZStack{
                Image("ContentView")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                    .imageScale(.large)
                VStack(alignment: .center){
                    
                    Text("Hi, my name is Michael. I'm from Nha Trang, VietNam. My childhood attaches with sea so I want to protect the ocean. Nowsaday, the ocean has been polluted by us humans. I want to transmit my message to our society in order to protect the ocean. We know that when we protect our ocean, we are protecting our future")
                        .font(.system(size: 20, weight: .regular, design: .rounded))
                        .foregroundColor(.white)
                        .frame(width: 650, height: 150, alignment: .leading)
                        .multilineTextAlignment(.center)
                    Image("me")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 400, alignment: .center)
                    Text("This is me when I was 7 years old. I remember I used to fly a kite in the beach with my friend back in my childhood. For a long time, I've associated the sea with my memories. Those are all pleasant recollections.")
                        .font(.system(size: 17, weight: .medium, design: .default))
                        .foregroundColor(.white)
                        .frame(width: 650, height: 150, alignment: .leading)
                        .multilineTextAlignment(.center)
                    
                }
            }
        }
        .onAppear {
            let sound = Bundle.main.path(forResource: "Sound1", ofType: "mp3")
            self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
            self.audioPlayer.play()
        }
        
        // go to view2
        .onTapGesture {
            AudioServicesPlaySystemSound(1322)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                viewRouter.currentPage = .page1
            }
        }
    }
}



