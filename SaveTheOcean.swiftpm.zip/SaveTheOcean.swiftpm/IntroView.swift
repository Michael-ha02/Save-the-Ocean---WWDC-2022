//
//  File.swift
//  MyApp
//
//  Created by Michael Ha on 4/15/22.
//

import SwiftUI
import AVFoundation

struct IntroView: View{
    @State var audioPlayer: AVAudioPlayer!
    @State var willMoveToNextScreen = false
    @StateObject var viewRouter: ViewRouter
    
    var body: some View{
        
        ZStack(alignment: .center){
            Image("IntroView")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
                .imageScale(.large)
            
        }
        .onAppear {
            let sound = Bundle.main.path(forResource: "Sound3", ofType: "mp3")
            self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
            self.audioPlayer.play()
        }
        
        // go to view2
        .onTapGesture {
            AudioServicesPlaySystemSound(1322)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                viewRouter.currentPage = .content
            }
        }
    }
}


